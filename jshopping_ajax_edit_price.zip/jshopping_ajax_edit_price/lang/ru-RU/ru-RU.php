<?php
defined('_JEXEC') or die();

define('_JSHOP_CLOSE',"Закрыть");
define('_JSHOP_EDIT_PRICE',"Редактировать цены");
define('_JSHOP_SAVE_MODIFICATION',"Сохранить изменения");
define('_JSHOP_SELECT_CURRENCY',"Выберите валюту");
define('_JSHOP_SELECT',"Выберите");
define('_JSHOP_PRICE',"Цена");
define('_JSHOP_OLD_PRICE',"Старая цена");
define('_JSHOP_QUANTITY',"Количество");
define('_JSHOP_EAN_PRODUCT',"Код товара");
